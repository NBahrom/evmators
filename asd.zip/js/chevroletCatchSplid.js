
var splideCh = new Splide( '#splidechevrolet', {
    perPage: 6,
    perMove: 1,
    direction: 'ttb',
    height   : '30rem',
    wheel    : true,
  } );
  splideCh.mount();



  