
var splidecontact = new Splide( '#splidecontact', {
    perPage: 6,
    perMove: 1,
    direction: 'ttb',
    height   : '30rem',
    wheel    : true,
  } );
  splidecontact.mount();