var splideT = new Splide( '#splideTesla', {
    perPage: 6,
    perMove: 1,
    direction: 'ttb',
    height   : '30rem',
    wheel    : true,
  } );
  splideT.mount();